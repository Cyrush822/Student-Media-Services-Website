<?php
require_once('../makefont/makefont.php');

MakeFont('HoboStd.ttf');
MakeFont('SnellRoundhand-BoldScript.ttf');
MakeFont('StencilStd.ttf');
MakeFont('RosewoodStd-Regular.ttf');

 ?>
