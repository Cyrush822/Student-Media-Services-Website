<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    $people = array('Bob Dylans', 'Jane Doe', 'Henie Zhang');

    ob_start();
    use setasign\Fpdi\Fpdi;
    require_once('fpdf/fpdf.php');
    require_once('fpdi/src/autoload.php');

    $pdf = new Fpdi('L','mm',array(215,279));
    //Add fonts
    $pdf->AddFont('HoboStd');
    $pdf->AddFont('RosewoodStd-Regular');
    $pdf->AddFont('SnellRoundhand-BoldScript');
    $pdf->AddFont('StencilStd');


    foreach ($people as $person) {
      // add a page
      $pdf->AddPage();
      // set the source file
      $pdf->setSourceFile('master1_old.pdf');
      // import page 1
      $tplIdx = $pdf->importPage(1);
      // use the imported page and place it at position 10,10 with a width of 100 mm
      $pdf->useTemplate($tplIdx, 0, 0);

      // now write some text above the imported page
      $pdf->SetFont('SnellRoundhand-BoldScript','U',50);
      $pdf->SetTextColor(72, 124, 159);
      $pdf->SetXY(10, 90);
      // $pdf->Write(0, 'Alexandria Lingling Madeline');
      $pdf->Cell(0, 0, $person, 0, false, 'C');

      $pdf->SetFont('StencilStd','U',22);
      $pdf->SetTextColor(220, 184, 63);
      $pdf->SetXY(58, 113);
      $pdf->Write(0, '31');

      $pdf->SetFont('StencilStd','U',22);
      $pdf->SetTextColor(220, 184, 63);
      $pdf->SetXY(218, 113);
      $text = "Game Dev";
      $pdf->Write(0,$text);

      $pdf->AddPage();
      // set the source file
      $pdf->setSourceFile('master1_old.pdf');
      // import page 1
      $tplIdx = $pdf->importPage(2);
      // use the imported page and place it at position 10,10 with a width of 100 mm
      $pdf->useTemplate($tplIdx, 0, 0);


    }

    // initiate FPDI


    $pdf->Output('I', 'certificates.pdf');
    ob_end_flush();
    ?>
  </body>
</html>
